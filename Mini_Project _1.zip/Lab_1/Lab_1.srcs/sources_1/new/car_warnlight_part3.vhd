library IEEE; 
use IEEE.STD_LOGIC_1164.ALL;
 
entity car_warnlight_part3 is 
port ( 
        door_closed : in STD_LOGIC; 
        key_in : in STD_LOGIC; 
        seat_pressure : in STD_LOGIC; 
        seat_belt_closed: in STD_LOGIC; 
        light_en : out STD_LOGIC; 
        status_warning : out STD_LOGIC_VECTOR(1 downto 0)
    ); end car_warnlight_part3; 
    
 architecture Behavioral of car_warnlight_part3 is 
    signal door_warning : STD_LOGIC;
    signal belt_warning : STD_LOGIC; 

begin 
    light_en <= (NOT(door_closed)AND key_in) OR (key_in AND seat_pressure AND NOT(seat_belt_closed)); 
    
    door_warning <= key_in AND (NOT door_closed); 
    belt_warning <= key_in AND seat_pressure AND (NOT seat_belt_closed); 
    
    
    light_en <= door_warning OR belt_warning;
     
    status_warning <= "11" when (door_warning = '1' AND belt_warning = '1') else 
                      "01" when (door_warning = '1' AND belt_warning = '0') else 
                      "10" when (door_warning = '0' AND belt_warning = '1') else 
                      "00";
end Behavioral;
