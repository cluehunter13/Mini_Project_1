library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use STD.textio.all;
use IEEE.std_logic_textio.all;

Entity car_warnlight_tb_part3 Is
end car_warnlight_tb_part3;

Architecture behavior of car_warnlight_tb_part3 Is


	Signal D, K, S, B, L : STD_LOGIC;
	Signal STATUS : STD_LOGIC_VECTOR(1 downto 0);
               		
begin
	uut: entity work.car_warnlight_part3 PORT MAP (
        door_closed => D,
        key_in => K,
        seat_pressure => S,
        seat_belt_closed => B,
        light_en => L,
        status_warning => STATUS);
	process
	begin
	
        -- ==========================================
        -- TEST 1: No warnings
        -- Door closed, key out, no person, belt closed
        -- Expected STATUS = 00
        -- ==========================================
        D <= '1'; 
        K <= '0'; 
        S <= '0'; 
        B <= '1'; 
        wait for 500 ns;
        
        -- ==========================================
        -- TEST 2: Door warning only
        -- Door open, key in, no person, belt closed
        -- Expected STATUS = 01
        -- ==========================================
        D <= '0';
        K <= '1';
        S <= '0';
        B <= '1';
        wait for 500 ns;

        -- ==========================================
        -- TEST 3: Seat-belt warning only
        -- Door closed, key in, person seated, belt open
        -- Expected STATUS = 10
        -- ==========================================
        D <= '1';
        K <= '1';
        S <= '1';
        B <= '0';
        wait for 500 ns;

        -- ==========================================
        -- TEST 4: Both warnings
        -- Door open, key in, person seated, belt open
        -- Expected STATUS = 11
        -- ==========================================
        D <= '0';
        K <= '1';
        S <= '1';
        B <= '0';

        wait for 500 ns;
      wait;		 
       
	end process;
end behavior;
