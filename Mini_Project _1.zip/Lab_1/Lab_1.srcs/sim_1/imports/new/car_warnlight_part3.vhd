library IEEE; 
use IEEE.STD_LOGIC_1164.ALL;
 
entity car_warnlight_part3 is 
port ( 
        door_closed : in STD_LOGIC; 
        key_in : in STD_LOGIC; 
        seat_pressure : in STD_LOGIC; 
        seat_belt_closed: in STD_LOGIC; 
        light_en : out STD_LOGIC; 
        warning_light : out STD_LOGIC; 
        door_warning : out STD_LOGIC; 
        belt_warning : out STD_LOGIC; 
        status_warning : out STD_LOGIC_VECTOR(1 downto 0)
    ); end car_warnlight_part3; 
    
 architecture Behavioral of car_warnlight_part3 is 
    signal door_warning_int : STD_LOGIC;
    signal belt_warning_int : STD_LOGIC; 

begin 
    light_en <= (NOT(door_closed)AND key_in) OR (key_in AND seat_pressure AND NOT(seat_belt_closed)); 
    
    door_warning_int <= key_in AND (NOT door_closed); 
    belt_warning_int <= seat_pressure AND (NOT seat_belt_closed); 
    
    -- Send internal signals to the output ports 
    door_warning <= door_warning_int; 
    belt_warning <= belt_warning_int; 
    
    warning_light <= door_warning_int OR belt_warning_int;
     
    status_warning <= "11" when (door_warning_int = '1' AND belt_warning_int = '1') else 
                      "01" when (door_warning_int = '1' AND belt_warning_int = '0') else 
                      "10" when (door_warning_int = '0' AND belt_warning_int = '1') else 
                      "00";
end Behavioral;
